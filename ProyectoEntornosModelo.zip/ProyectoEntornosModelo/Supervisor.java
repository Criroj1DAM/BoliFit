package ProyectoEntornosModelo;

public class Supervisor extends Empleado {
	
	private int antiguedad;
	
	private double productividad;
	
	
	public Supervisor (String dni, String nombre, int antiguedad, double productividad){
		
		super(dni, nombre, 1800+productividad);
		
		this.antiguedad=antiguedad;
		
		this.productividad=productividad;
		
	}

	public int getAntiguedad() {
		
		return antiguedad;
		
	}

	public double getProductividad() {
		
		return productividad;
		
	}
	
	public  void modificarSueldo(int cantidad) {
		
		sueldo=sueldo+cantidad;
		
	}

	public String toString() {
		
		return super.toString() + "Supervisor [antiguedad:" + antiguedad + ", productividad:" + productividad + "]";
	}
	

}
