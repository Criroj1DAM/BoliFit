package ProyectoEntornosModelo;

import java.util.ArrayList;

public class Zona {
	
	private String nombre;
	
	private ArrayList<Empleado> empleados;
	
	private int capacidad;
	
	private int capacidadEmpleados;
	
	private static int cont=1;
	
	
	public Zona() {
		
		nombre="Seccion A"+cont++; 
		
		empleados=new ArrayList<Empleado>();
		
		capacidad=15;
		
		capacidadEmpleados=4;
		
	}

	public String getNombre() {
		
		return nombre;
		
	}

	public void setNombre(String nombre) {
		
		this.nombre = nombre;
		
	}

	public int getCapacidad() {
		
		return capacidad;
		
	}

	public void setCapacidad(int capacidad) {
		
		this.capacidad = capacidad;
		
	}

	public ArrayList<Empleado> getMonitores() {
		
		return empleados;
		
	}
	
	public void annadirEmpleado(Empleado empleado) {
		
		if(empleados.size()<capacidadEmpleados) {
			
			empleados.add(empleado);
			
		}
		else {
			
			System.out.println("No se pueden añadir mas Empleados");
		}
		
		
	}
	
	public void borrarEmpleado(Empleado empleado) {
		
		int indice=-1;
		
		for(int i=0; i<empleados.size(); i++) {
			
			if(empleados.get(i).getCodigoEmpleado()==empleado.getCodigoEmpleado()) {
				
				indice=i;
				
				break;
			}
		}
		
		if(indice!=-1) {
			
			empleados.remove(indice);
		}
		
	}

	public String toString() {
		
		return "Zona [nombre:" + nombre + ", monitores:" + empleados + ", capacidad:" + capacidad + " personas" +  "]";
	}

}
