package ProyectoEntornosModelo;

import java.util.ArrayList;

public class Gimnasio {
	
	private String nombre;
	
	private String ciudad;
	
	private ArrayList<Zona> zonas;
	
	private ArrayList<Cliente> clientes;
	
	
	public Gimnasio(String nombre, String ciudad) {
		
		this.nombre=nombre;
		
		this.ciudad=ciudad;
		
		zonas=new ArrayList<Zona>();
		
		clientes=new ArrayList<Cliente>();
		
	}

	public String getNombre() {
		
		return nombre;
		
	}

	public void setNombre(String nombre) {
		
		this.nombre = nombre;
		
	}

	public String getCiudad() {
		
		return ciudad;
		
	}

	public ArrayList<Zona> getZonas() {
		
		return zonas;
		
	}

	public ArrayList<Cliente> getClientes() {
		
		return clientes;
		
	}
	
	public void annadirZona(Zona zona) {
		
		zonas.add(zona);
		
	}
	
	public void annadirCliente(Cliente cliente) {
		
		clientes.add(cliente);
		
	}
	
	public void borrarCliente(Cliente cliente) {
		
		int indice=-1;
		
		for(int i=0; i<clientes.size(); i++) {
			
			if(clientes.get(i).getCodigoCliente()==cliente.getCodigoCliente()) {
				
				indice=i;
				
				break;
			}
		}
		
		if(indice!=-1) {
			
			clientes.remove(indice);
			
			System.out.println("Cliente dado de baja correctamente");
			
		}
	}

	public String toString() {
		
		return "Gimnasio [nombre:" + nombre + ", ciudad:" + ciudad + ", zonas:" + zonas + ", clientes:" + clientes
				+ "]";
	}
	
	
}
