package ProyectoEntornosModelo;

import java.util.Scanner;

public class MainGimnasio {
	
	private static Scanner entrada=new Scanner(System.in);

	public static void main(String[] args) {
		
		Gimnasio gimnasio=new Gimnasio("TerraFit", "Madrid");
		
		int opcion;
		
		do {
			
			System.out.println("OPCIONES: 1-DAR ALTA CLIENTE, 2-DAR BAJA CLIENTE, 3-MODIFICAR AFILIACION CLIENTE 4-ALTA EMPLEADO"
					+ " 5-DESPIDO EMPLEADO,6-AÑADIR ZONA, 7-AÑADIR EMPLEADO A ZONA, 8-MOSTRAR CLIENTES, 9-MOSTRAR EMPLEADOS O "
					+ "10-SALIR DLE PROGRAMA");
			
			opcion=entrada.nextInt();
			
			switch(opcion) {
			
			case 1:
				
				System.out.println("HAS ELEGIDO DAR DE ALTA UN CLIENTE");
				
				AltaCliente(gimnasio);
				
				break;
				
			case 2:
				
				break;
				
			case 3:
				
				break;
				
			case 4:
				
				break;
				
			case 5:
	
				break;
	
			case 6:
	
				break;
	
			case 7:
	
				break;
	
			case 8:
				
				System.out.println("HAS ELEGIDO MOSTRAR LOS CLIENTES");
				
				mostrarClientes(gimnasio);
	
				break;
	
			case 9:
	
				break;
	
			case 10:
	
				break;
				
			default:
				
				System.out.println("ERROR, escoge una opcion entre 1-10");
				
				}
			
			
		}while(opcion!=10);

	}
	
	public static void AltaCliente(Gimnasio gimnasio) {
		
		System.out.println("Dime que tipo de paquete tiene el cliente: 1-BASICO, 2-ESTANDAR- 3-PREMIUM");
		
		int opcion=entrada.nextInt();
		
		Cliente cliente = null;
		
		
		System.out.println("Dime el dni del cliente");
		
		String dni=entrada.next();
		
		System.out.println("Dime el nombre del cliente");
		
		String nombre=entrada.next();
		
		System.out.println("Dime el apellido del cliente");
		
		String apellido=entrada.next();
		
		System.out.println("Dime el numero de telefono del cliente");
		
		String tel=entrada.next();
		
		System.out.println("Dime el correo electronico del cliente");
		
		String correo=entrada.next();
		
		System.out.println("Dime la direccion del cliente");
		
		String direccion=entrada.next();
		
		if(opcion==1) {
			
			cliente=new AfiliadoBasico(dni, nombre, apellido, tel, correo, direccion);
			
			System.out.println("Cliente con el paquete Afiliado Basico dado de alta correctamente");
			
		}
		else if(opcion==2) {
			
			System.out.println("Dime cuanto vas a pagar en el primer pago");
			
			double PP=entrada.nextDouble();
			
			System.out.println("Dime cuanto vas a pagar en el segundo pago");
			
			double SP=entrada.nextDouble();
			
			if(PP+SP==400) {
				
				cliente=new AfiliadoEstandar(dni, nombre, apellido, tel, correo, direccion, PP, SP);
				
				System.out.println("Cliente con el paquete Afiliado Estandar dado de alta correctamente");
				
			}
		
		}else {
			
			cliente=new AfiliadoPremium(dni, nombre, apellido, tel, correo, direccion);
			
			System.out.println("Cliente con el paquete Afiliado Premium dado de alta correctamente");
			
			
		}
		
		gimnasio.annadirCliente(cliente);
		
		
		}
	
	public static void mostrarClientes(Gimnasio gimnasio) {
		
		for(int i=0; i<gimnasio.getClientes().size(); i++) {
			
			System.out.println(gimnasio.getClientes().get(i).toString());
			
		}
	}
	
	
}
